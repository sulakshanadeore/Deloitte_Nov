﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerializationDemo
{
   [Serializable()]
    public class Customer
    {
        public int Custid { get; set; }
        public string Custname { get; set; }
        public int CustPoints { get; set; }

        [NonSerialized]
        private int _creditLimit;
      public int CreditLimit
        { 
            get { return _creditLimit; } 
            set { _creditLimit = value; } }
    }
}

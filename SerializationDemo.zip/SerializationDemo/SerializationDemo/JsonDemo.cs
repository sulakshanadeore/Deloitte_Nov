﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
namespace SerializationDemo
{
    class JsonDemo
    {
        static void Main(string[] args)
        {
            //Customer c1 = new Customer();
            //c1.Custid = 10;
            //c1.Custname = "Gauri";
            //c1.CustPoints = 1000;
            //string custdata=JsonConvert.SerializeObject(c1);
            //FileStream fs = new FileStream("customer1.json", FileMode.Create, FileAccess.Write);
            //StreamWriter sw = new StreamWriter(fs);
            //sw.Write(custdata);
            //sw.Close();
            //fs.Close();
            //Console.WriteLine("Done");

           

            FileStream fs = new FileStream("customer1.json", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string s=sr.ReadToEnd();

            Customer c = (Customer)JsonConvert.DeserializeObject(s, typeof(Customer));
            Console.WriteLine(c.Custid);
            Console.WriteLine(c.Custname);
            Console.WriteLine(c.CustPoints);
            Console.WriteLine(c.CreditLimit);


            Console.Read();
        }
    }
}

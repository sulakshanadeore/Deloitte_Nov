﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
namespace SerializationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Serialize-- - Binary
            Customer c = new Customer();
            c.Custid = 10;
            c.Custname = "Gauri";
            c.CustPoints = 1000;
            c.CreditLimit = 10000;

            FileStream fs = new FileStream("custdata.bin", FileMode.Create, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, c);
            fs.Close();

            //Deserialize--Binary
            FileStream fs2 = new FileStream("custdata.bin", FileMode.Open, FileAccess.Read);
            BinaryFormatter bf2 = new BinaryFormatter();
            Customer c1 = (Customer)bf2.Deserialize(fs2);
            Console.WriteLine(c1.Custid);
            Console.WriteLine(c1.Custname);
            Console.WriteLine(c1.CreditLimit);
            Console.WriteLine(c1.CustPoints);
           Console.Read();


        }
    }
}

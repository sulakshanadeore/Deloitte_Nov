﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
namespace SerializationDemo
{
    class XMLSerializationDemo
    {
        static void Main(string[] args)
        {
            //Customer c = new Customer();
            //c.Custid = 10;
            //c.Custname = "Gauri";
            //c.CustPoints = 1000;
            ////  c.CreditLimit = 10000;//private

            //FileStream fs1 = new FileStream("customerdata.xml",FileMode.Create,FileAccess.Write);
            //XmlSerializer xs = new XmlSerializer(typeof(Customer));
            //xs.Serialize(fs1, c);
            //fs1.Close();

            //FileStream fs1 = new FileStream("customerdata.xml", FileMode.Open, FileAccess.Read);
            //XmlSerializer xs = new XmlSerializer(typeof(Customer));
            //Customer c=(Customer)xs.Deserialize(fs1);
            //Console.WriteLine(c.Custid);
            //Console.WriteLine(c.Custname);
            //Console.WriteLine(c.CustPoints);
            //fs1.Close();


            Console.Read();


        }
    }
}

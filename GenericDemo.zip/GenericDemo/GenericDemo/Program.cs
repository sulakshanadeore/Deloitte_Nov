﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //List<int> li = new List<int>();
            //li.Add(100);
            //li.Add(200);
            //li.Add(3400);

            //int sum=li.Sum();
            //Console.WriteLine(sum);
            //Console.ReadKey();


            //Stack<int> s = new Stack<int>();
            //s.Push(13);

            //Queue<string> q = new Queue<string>();
            Dictionary<int, int> d = new Dictionary<int, int>();
            d.Add(1, 200);
            d.Add(2, 200);
            d.Add(3, 200);
            d.Add(4, 400);
            KeyValuePair<int, int> d1 = d.First();
            Console.WriteLine(d1.Key);
            Console.WriteLine(d1.Value);

            Dictionary<int,int>.Enumerator de=d.GetEnumerator();
            while (de.MoveNext())
            {
                Console.WriteLine(de.Current.Key + " " + de.Current.Value);
            }

            Console.WriteLine("Second way");
            IEnumerable<KeyValuePair<int, int>> d2 = d.AsEnumerable();
            foreach (var item in d2)
            {
                Console.WriteLine(item.Key +  " " + item.Value);
            }

            Console.ReadLine();



        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CnstructorDemo
{
    class Customer
    {
        static int custid;
        static Customer()
        {
            Console.WriteLine("this is a static constructor, its gets called once in the lifetime of the class and it gets called before any other constructor is called...");
            custid = 0;

        }



        public Customer()
        {
            Console.WriteLine("This is  a default constructor");
            
           // Console.WriteLine("Your customerid " + custid);
            
        }


        public Customer(string custname)
        {

            this.CustomerName = custname;
            Console.WriteLine("Parameterised Customer");
        
        }

        public Customer(string custname, string city):this(custname)
        {
            //this.CustomerName = custname;
            this.City = city;

        }
        public Customer(string custname, string city, string state):this(custname,city)
        {
            //this.CustomerName = custname;
            //this.City = city;
            this.State = state;
        
        }
        public string State { get; set; }

        public string City { get; set; }

        public int CustomerID 
        { 
            get 
            {
                custid += 1;
                return custid; 
            } 
        }

        public string CustomerName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CnstructorDemo
{
    class SpecialCustomer:Customer
    {
        public SpecialCustomer():base()
        {

            Console.WriteLine("Default of Special Customer");
                
        }

        public SpecialCustomer(string custname)
        {
            Console.WriteLine("Special parameterised.....");
        }
    }

    
}

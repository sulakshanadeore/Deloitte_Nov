﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CnstructorDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            //Customer c = new Customer();
            //Console.WriteLine("Your customerid =" + c.CustomerID);
            //Customer c1 = new Customer();
            //Console.WriteLine();
            //Console.WriteLine("Your customerid =" + c1.CustomerID);
            //Console.WriteLine();
            //Customer c2 = new Customer("Jack");
            //Console.WriteLine("Your customerid =" +c2.CustomerID);
            //Customer c3 = new Customer("Jack", "Bangaluru");

            //SpecialCustomer sp = new SpecialCustomer("hari");
            SpecialCustomer sp = new SpecialCustomer();

            Console.Read();
            
        }
    }
}

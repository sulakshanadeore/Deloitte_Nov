﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;  
namespace FileWorkingUsingReadersAndWriters
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Select One");
            Console.WriteLine("===========");
            Console.WriteLine();
            Console.WriteLine("1.Create a file 2. read from file 3. Exit");
            Console.WriteLine("enter your choice");
            int ch = Convert.ToInt32(Console.ReadLine());

            switch (ch)
            {
                case 1:
                    Console.WriteLine("entr file name:");
                    string fname = Console.ReadLine();
                    FileStream fs = new FileStream(fname, FileMode.Create, FileAccess.Write);

                    StreamWriter sw = new StreamWriter(fs);
                    sw.Write("Hello World creating my first file");
                    sw.Flush();
                    sw.Close();
                    fs.Flush();
                    fs.Close();
                    fs.Dispose();
                    sw.Dispose();
                    break;
                default:
                    break;
            }

            


        }
    }
}

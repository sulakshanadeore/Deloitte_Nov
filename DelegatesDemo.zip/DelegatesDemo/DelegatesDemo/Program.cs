﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRLibrary;
namespace DelegatesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();//3 object of class
            Calculates del = new Calculates(emp.M1);
            int sqrtAns=del(100);
            Console.WriteLine(sqrtAns);

            ConvertToUpper cu = new ConvertToUpper(emp.stringtoUpper);
            string c=cu("good morning");
            Console.WriteLine(c);

            AddString add = new AddString(emp.concatString);//4 object of delegate & pass the method reference
            //add("Hello ", "Jeevan");//Invoke/call
            //add.Invoke("Hello ", "Jeevan");

            AddString add1 = new AddString(emp.replaceChars);
            //add1("Hello", "World");


            AddString a=(AddString)Delegate.Combine(add, add1);
            a("Hello", "World");


            //Second way
            //int[] i = new int[2] { 1, 2 };
            AddString[] delarr = new AddString[2] {emp.concatString,emp.replaceChars };
            AddString finalObj=(AddString)MulticastDelegate.Combine(delarr);
            finalObj("Good ", "morning");

           
            

            Console.ReadKey();


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRLibrary;
namespace DelegatesDemo
{
    class AnonymousDemo
    {
        static void Main(string[] args)
        {

            //public delegate int Calculates(double i);
       
            Calculates c1 = delegate (double p1) {
                return (int)Math.Sqrt(p1);

            };

            int a=c1(100);
            Console.WriteLine(a);
            Console.WriteLine("----------------------");

            ConvertToUpper cu = delegate (string s) 
            {
                string s1=s.ToUpper();
                return s1;
            };
            string output=cu.Invoke("hello");
            Console.WriteLine(output);

            Console.WriteLine("---------------------");

            AddString addString = delegate (string s1, string s2) {
                s1=s1.ToLower();
                s2 = s2.ToUpper();

                Console.WriteLine(string.Concat(s1, s2));
            };



            addString("HELLO ", "BANGALORE");




            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRLibrary;
namespace DelegatesDemo
{
    class collectionsWithDelegates
    {
        static void Main(string[] args)
        {
            List<Dept> depts = new List<Dept>();
            depts.Add(new Dept {Deptno=10,Dname="HR",Loc="Pune",TotalSal=100000 });
            depts.Add(new Dept { Deptno = 20, Dname = "Dev", Loc = "Bangalore",TotalSal=100000 });
            depts.Add(new Dept { Deptno = 30, Dname = "Training", Loc = "Pune",TotalSal=200000 });
            Dept d = new Dept();
            d.Deptno = 40;
            d.Dname = "Logistics";
            d.Loc = "Chennai";
            d.TotalSal = 400000;
            depts.Add(d);

            //public delegate int FindMinOfAllSal(List<Dept> ds);
            Func<List<Dept>, int> fSmall = delegate (List<Dept> list) {
                
                   int minsal =list.Min(item=>item.TotalSal);
                return minsal;
                   
            };

            int minsalary=fSmall(depts);
            Console.WriteLine(minsalary);



            //Dept found=depts.Find(d1 => d1.Loc == "Pune");

            //List<Dept> found=depts.FindAll(d1 => d1.Loc == "Pune");

            //double a =depts.Average(d1 => d1.TotalSal);
            // Console.WriteLine(a);


            //bool ans=depts.All(d1 => d1.Dname.Length >= 5);
            //Console.WriteLine(ans);


            //bool ans1 = depts.All(d2 => d2.Dname.Length >= 2);
            //Console.WriteLine(ans1);

            //depts.ForEach(
            //    d2 =>
            //Console.WriteLine(d2.Deptno + d2.Dname + d2.Loc + d2.TotalSal)
            //);

            


             

            //if (found!=null)
            //{
            //    foreach (var item in found)
            //    {
            //        Console.WriteLine("This deptno exists");
            //        Console.WriteLine(item.Deptno);
            //        Console.WriteLine(item.Dname);
            //        Console.WriteLine(item.Loc);
            //    }

            //}
            //else
            //{
            //    Console.WriteLine("this deptno doesn't exists");
            //}


            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRLibrary;
namespace DelegatesDemo
{
    class FunctionLambda
    {
        static void Main(string[] args)
        {
            //=>//lambda
            //parameter names--()

            //3 types 
            //    Func---return type
            //    Action ---return void
            //    Predicate---return bool

            //public delegate int Calculates(double i);
            //public delegate float Sum(int i,int j);

            //Employee emp = new Employee();
            //Func<double, int> f = emp.M1;
            //int a=f(64);
            //Console.WriteLine(a);

            //Func<double, int> f = delegate (double p) {
            //    return (int)Math.Sqrt(p);
            //};

            //int ans=f(81);
            //Console.WriteLine(ans);


            //Func<double, int> f = (p) => 
            //{ 
            //    return (int)Math.Sqrt(p); 
            //};

            //int ans=f(25);
            //Console.WriteLine(ans);


            Func<string, int> strLen = (s) => {
                int len = s.Length;
                return len;
            };


            int l=strLen("JackAndJill");
            Console.WriteLine(l);


            Func<int, double> square = (i) => { return i * i; };


            double ans=square(10000);
            Console.WriteLine(ans);

            Action<int, int, int> action = (i1,i2,i3) => {
                int ans1 = i1 + i2 + i3;
                Console.WriteLine(ans1);
            
            };

            action(10, 20, 30);

            Predicate<int> isEven = (no1) => {
                bool status=false;
                if (no1%2==0)
                {
                    status = true;
                }
                return status;
            };

            bool ansIsEven=isEven(10);
            Console.WriteLine(ansIsEven);


            Console.ReadKey();

            




    }
    }
}

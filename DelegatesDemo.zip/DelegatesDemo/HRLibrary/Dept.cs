﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRLibrary
{
    public class Dept
    {
        public int Deptno { get; set; }
        public string Dname { get; set; }
        public string Loc { get; set; }
        public int TotalSal { get; set; }

        public int FindSmallestSalary(List<Dept> dlsit)
        {
            int minsal = 0;
            Action<List<Dept>> fSmall = delegate (List<Dept> list)
            {

          minsal = list.Min(item => item.TotalSal);

                
            };
            return minsal;
        }
    }
}

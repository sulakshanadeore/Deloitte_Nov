﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRLibrary
{
    public delegate int Calculates(double i);
    public delegate string ConvertToUpper(string s);
    public delegate void AddString(string s1, string s2);//declare
    public class Employee
    {



        public int M1(double i)
        {
            //int ans=(int)Math.Sqrt(i);
            return (int)Math.Sqrt(i);
        }

        public string stringtoUpper(string s)
        {
            return s.ToUpper();
        
        }

        public void concatString(string fstring, string sstring)//writing 
        {
            string tstring=string.Concat(fstring, sstring);
            Console.WriteLine(tstring);
        }

        public void replaceChars(string fstring, string sstring)//writing 
        {
           fstring= fstring.Replace('o', 'O');
            sstring=sstring.Replace('o', 'O');
            Console.WriteLine(fstring);
            Console.WriteLine(sstring);
        }





    }
}

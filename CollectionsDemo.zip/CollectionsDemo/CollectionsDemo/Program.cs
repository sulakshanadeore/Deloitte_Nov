﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //     WorkingWithArrayList();

            //WorkingWithStack();
            //WorkingWithQueue();
            Hashtable h = new Hashtable();
            h.Add(1, 100);
            h.Add("2", 200);
            h.Add('1', 100);
            h.Remove('1');
            //h.Clear();

            //IDictionaryEnumerator ie=h.GetEnumerator();
            //while (ie.MoveNext())
            //{
            //    Console.WriteLine(ie.Value  + " " + ie.Key);
            //}

            foreach (var item in h.Values)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("------------");

            foreach (var item in h.Keys)
            {
                Console.WriteLine(item);
            }




            Console.ReadLine();

        }

        private static void WorkingWithQueue()
        {
            Queue q = new Queue();//FIFO
            q.Enqueue(33);
            q.Enqueue("hello");
            q.Enqueue(6677);
            object o = q.Dequeue();//removes 33
            q.Peek();//hello
            //q.ToArray();
            bool ans = q.Contains(6677);
            Console.WriteLine(ans);
        }

        private static void WorkingWithStack()
        {
            Stack s = new Stack(2);//LIFO
            s.Push(1);
            s.Push(1.33f);
            s.Push("sdfsf");
            s.Push(344);
            int i = (int)s.Pop();//344

            foreach (var item in s)
            {
                Console.WriteLine(item);

            }

            Array arr1 = Array.CreateInstance(typeof(object), s.Count);
            s.CopyTo(arr1, 0);

            object topmost = s.Peek();
            Console.WriteLine(topmost);
        }

        private static void WorkingWithArrayList()
        {
            ArrayList list = new ArrayList();
            list.Add(13);
            list.Add(13.35f);
            list.Add("hello");
            list.Add('A');
            list.Add(new DateTime(2002, 01, 12));
            list.Add(456.33d);
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("------------------");
            int cnt = list.Count;
            Console.WriteLine(cnt);
            object[] arr = list.ToArray();
            list.Insert(1, 100);
            int[] arr1 = new int[3] { 200, 2000, 20000 };
            list.InsertRange(1, arr1);
            list.AddRange(arr1);
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
        }
    }
}

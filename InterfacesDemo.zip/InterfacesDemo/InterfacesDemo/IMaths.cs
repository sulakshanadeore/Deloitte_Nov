﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesDemo
{
    interface IMaths
    {
        void Add(int i, int j);
        double Power(int i, int j);
    }

    interface ITrignometry
    {
        double CalculateAreaOfCircle(int radius);


    }

    class AdvancedMaths:ITrignometry
    {
        public double CalculateAreaOfCircle(int radius)
        {
            return Math.PI * radius * radius;
        }

        public double Multiply(int i, int j)
        {
            return i * j;
        }
    }

    class Maths : IMaths,ITrignometry
    {
        public void Add(int i, int j)
        {
            //throw new NotImplementedException();
            int k = i + j;
            Console.WriteLine(k);
        }

        public double CalculateAreaOfCircle(int radius)
        {
            //throw new NotImplementedException();
            
            double area = Math.PI * radius * radius;
            int a = (int)area;
            Console.WriteLine(a);
            return area;

        }

        public double Power(int i, int j)
        {
            //throw new NotImplementedException();
            double ans=Math.Pow(i, j);
            return ans;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            Maths m = new Maths();
            double area=m.CalculateAreaOfCircle(20);
            Console.WriteLine(area);
        }
    }
}

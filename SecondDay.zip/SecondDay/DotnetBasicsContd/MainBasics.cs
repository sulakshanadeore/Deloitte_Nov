﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotnetBasicsContd
{
    class MainBasics
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number");
            int i = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter a number");
            int j = Convert.ToInt32(Console.ReadLine());

            int ans = i + j;
            Console.WriteLine($"{i} + {j}={ans}");
            ////Console.WriteLine("the answer=" + ans);
            //Console.WriteLine("the addition of {0} + {1}={2}", i, j, ans);

            //string s1 = string.Format("the addition of {0} + {1}={2}", i, j, ans);
            //Console.WriteLine(s1);


            //DateTime dt = new DateTime(2022,11,16);
            //Console.WriteLine("{0:d}",dt);
            //Console.WriteLine("{0:D}", dt);
            //Console.WriteLine("{0:m}", dt);
            //Console.WriteLine("{0:y}", dt);

            //int amt = 1000;
            //Console.WriteLine("{0:c}", amt);









            Console.ReadLine();
        }
    }
}

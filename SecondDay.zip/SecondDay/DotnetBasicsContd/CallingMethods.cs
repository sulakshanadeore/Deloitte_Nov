﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotnetBasicsContd
{
    class CallingMethods
    {
        static void SwapCallByValue(int i, int j)
        {
            int k = i;
            i = j;
            j = k;
        }
        static void SwapCallByReference(ref int i, ref int j)
        {
            int k = i;
            i = j;
            j = k;
        }

        static void AddNos(int i, int j, out double ans)
        {
            ans = i + j;
        }

        static int DoAddAndSubtract(int i, int j, out double ans)
        {
            int sub = i - j;
            ans = i + j;
            return sub;
        }

        static void doCalculations(int i, int j, out int addans, out int subans, out int mulans)
        {
            addans = i + j;
            subans = i - j;
            mulans = i*j;
        
        }
         static void Main(string[] args)
        {
            int fno = 10;
            int sno = 20;
            double ans1;


            int aans,sans,mans;
            doCalculations(fno, sno, out aans, out sans,out mans);
            Console.WriteLine(aans);
            Console.WriteLine(sans);
            Console.WriteLine(mans);
            Console.WriteLine("-------------------");



            AddNos(fno, sno, out ans1);
            Console.WriteLine(ans1);

            Console.WriteLine("-------------------------------------");

            int subans =DoAddAndSubtract(fno, sno, out ans1);
            Console.WriteLine(ans1);
            Console.WriteLine(subans);




            //SwapCallByValue(fno,sno);//values & not address of fno and sno
            //Console.WriteLine(fno);
            //Console.WriteLine(sno);
            //Console.WriteLine("-------------------------------");
            //SwapCallByReference(ref fno, ref sno);
            //Console.WriteLine(fno);
            //Console.WriteLine(sno);



            Console.ReadKey();





        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotnetBasicsContd
{
    class Program1
    {
        static void Main(string[] args)
        {
            char c = 'a';
            int asciivalue = (int)c;
            Console.WriteLine(asciivalue);

            //Console.WriteLine("enter 4 digit number");
            //int num = Convert.ToInt32(Console.ReadLine());//1234
            //int sum = 0, n;

           

            //while (num>0)
            //{
            //    n = num % 10;
            //    Console.WriteLine(n);
            //    sum = sum + n;
            //    num = num / 10;

            //}
            //Console.WriteLine(sum);
            Console.ReadLine();
        }

    }
}

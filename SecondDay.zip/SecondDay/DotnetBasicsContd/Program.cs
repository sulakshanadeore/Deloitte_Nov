﻿using System;


namespace DotnetBasicsContd
{

    class Employee
    {

        internal  void GenerateEmployeeid()
        {
            int j = 10000;
            //Console.WriteLine(j);//1
            //j = j + 1;//2
        }
    }
    class Program
    {
        static double CalculateAreaCircle(int radius)
        { 

        return Math.PI* radius*radius;
        }
        static int i = 10;
       static void Main(string[] args)
        {
            double area = CalculateAreaCircle(10);
            //double area=Program.CalculateAreaCircle(10);
            Console.WriteLine(area);
            Console.WriteLine(CalculateAreaCircle(10));
            Console.WriteLine("----------------");
            Console.WriteLine(10+11);
            Console.WriteLine("---------------");
             //const float pi = 3.14f;
            int i = 20;
            Console.WriteLine(i);//20
            i = i + 1;//21
            Console.WriteLine(i);//21
            i = i + 1;
            Console.WriteLine(i);//22
            Console.WriteLine("--------------------");
            Console.WriteLine(Program.i);//10
            Program.i = Program.i + 1;
            Console.WriteLine(Program.i);//11
            Program.i = Program.i + 1;
            Console.WriteLine(Program.i);//12
             Program.i = Program.i + 1;
            Console.WriteLine(Program.i);//13



            Console.Read();
        }
    }
}

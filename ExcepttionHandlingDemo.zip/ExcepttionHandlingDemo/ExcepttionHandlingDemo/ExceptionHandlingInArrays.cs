﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcepttionHandlingDemo
{
    class ExceptionHandlingInArrays
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[] { 9, 18, 65, 45, 33 };
            int[] divisors = new int[] { 3, 0, 0, 5 };
            try
            {
                for (int j = 0; j < numbers.Length; j++)
                {

                    try
                    {
            Console.WriteLine("Number: " + numbers[j] +"\n" + "Divisors:" + divisors[j] +"\n" + "Quotient" + numbers[j]/divisors[j]);
                        Console.WriteLine("----------------------");
                    }

                    catch (DivideByZeroException ex)
                    {
                        //Console.WriteLine(ex.Message);

                        Console.WriteLine("divide by zero----Inner try catch executed.....");
                        Console.WriteLine("-------------------------");
                    }
                }
            }
            catch (IndexOutOfRangeException ex)
            {

                Console.WriteLine("Index Out of range----Outer block executed.... ");
            }
            Console.ReadLine();
        }
    }
}

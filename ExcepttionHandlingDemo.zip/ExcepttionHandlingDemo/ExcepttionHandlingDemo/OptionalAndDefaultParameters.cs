﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcepttionHandlingDemo
{
    class OptionalAndDefaultParameters
    {
        static void Main(string[] args)
        {

            Calculate(10, 30);

            Console.Read();
        }
        //Optional
        static void Calculate(int i, int j=10)
        {
            Console.WriteLine(i+j);
        }

    }
}

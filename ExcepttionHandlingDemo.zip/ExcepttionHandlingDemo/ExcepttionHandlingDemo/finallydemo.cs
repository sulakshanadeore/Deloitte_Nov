﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace ExcepttionHandlingDemo
{
    class finallydemo
    {
        static void Main(string[] args)
        {
            FileStream fs = null;
            StreamReader sr = null;
            try
            {
                fs = new FileStream("a1.txt", FileMode.Open, FileAccess.Read);
                
                
                try
                {
                    sr = new StreamReader(fs);
                    Console.WriteLine(sr.ReadToEnd());
                   
                }
                catch (Exception ex)
                {

                    Console.WriteLine("Some error occured.....");
                }



            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine(ex.Message);
                //Console.WriteLine(ex.StackTrace);
                //Console.WriteLine(ex.InnerException.Data);

            }
            
            finally
            {

                sr.Close();
                sr.Dispose();


                fs.Close();
                fs.Dispose();
                Console.WriteLine("finally called");


            }
            Console.ReadLine();

        }
    }
}

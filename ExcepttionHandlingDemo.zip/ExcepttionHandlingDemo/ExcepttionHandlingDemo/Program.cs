﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcepttionHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int i=0, j=0, k=0;
            try
            {
                Console.WriteLine("Enter a number");
                i = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter a number");
                j = Convert.ToInt32(Console.ReadLine());
                k = i / j;
                Console.WriteLine(k);

            }

            catch (DivideByZeroException ex)
            {

                Console.WriteLine(ex.Message);
                Console.WriteLine("Pls check denominator");

            }

            catch (OverflowException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            Console.ReadLine();


        }
    }
}

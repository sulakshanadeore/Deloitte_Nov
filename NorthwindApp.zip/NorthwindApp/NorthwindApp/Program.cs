﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NortwindLibrary;
namespace NorthwindApp
{
    class Program
    {
        static void Main(string[] args)
        {


            // Products p = new Products();
            // p.Prodid = 1;
            // p.Prodname = "Chai";
            // p.Price = 10;
            // p.Qty = 30;
            //double val= p.CalculatePrice();
            // Console.WriteLine(val);
            // Categories c = new Categories();
            // c.DisplayCategories();

            // int i=c.FindCategory(1);
            // Console.WriteLine(i);

            // Console.WriteLine("--------------------");

            try
            {
                HistoricalBooks h = new HistoricalBooks();
                h.FindBooksDetailsByID(0);
            }
            catch (BookNotFoundException ex)
            {
                //ex.Message = "Not found any book with this id...pls check again";
                Console.WriteLine("Not found any book with this id...pls check again");
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
           


            Console.Read();

        }
    }
}

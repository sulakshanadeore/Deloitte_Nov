﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NortwindLibrary
{

    [Serializable]
    public class ProductNotFoundException : Exception
    {
        public ProductNotFoundException() { }
        public ProductNotFoundException(string message) : base(message) { }
        public ProductNotFoundException(string message, Exception inner) : base(message, inner) { }
        protected ProductNotFoundException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
    public class Products
    {
        private int? _prodid; 
        public int? Prodid 
        { 
            get 
            { return _prodid;  } 
            set
            {
                if (string.IsNullOrEmpty(value.ToString()) || value<=0)
                {
                    throw new ProductNotFoundException("Invalid input");
                }
            } 
        }
        public string Prodname { get; set; }
        public int Price { get; set; }
        public int Qty { get; set; }

        public double CalculatePrice()
        {
            int amt = Qty * Price;
            return amt;
        
        }
    }
}

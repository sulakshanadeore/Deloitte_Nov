﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NortwindLibrary
{

   public class Categories : ICategories
    {
        public void DisplayCategories()
        {
            Console.WriteLine("category 1");
            Console.WriteLine("category 2");
            Console.WriteLine("category 3");
            // throw new NotImplementedException();
        }

        public int FindCategory(int id)
        {
            return 0;
            //throw new NotImplementedException();
        }
    }
     interface ICategories
    {
         void DisplayCategories();
         int FindCategory(int id);


    }
}

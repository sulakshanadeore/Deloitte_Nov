﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NortwindLibrary
{
  public  abstract class Books
    {

        public int Bookid { get; set; }
        public string BookName { get; set; }
        public string Author { get; set; }
        public int pages { get; set; }
        public float Price { get; set; }
        public string PubId { get; set; }
        public string PubName { get; set; }
        public string Emailid { get; set; }
        public string Address { get; set; }
        public string City { get; set; }

        //Atleast one member of this class must be abstract
        public abstract void BookDescription();
        public  void ShowPublisherDetails()
        {
            Console.WriteLine("Pubisher id " + PubId);
            Console.WriteLine("Pubisher Name " +   PubName);
            Console.WriteLine("Pubisher Email " + Emailid);
            Console.WriteLine("Pubisher address " + Address);
            Console.WriteLine("Pubisher city" + City);


        
        }

        public abstract void FindBooksDetailsByID(int id);

        
    }
 public   class HistoricalBooks : Books
    {
        public override void BookDescription()
        {
            Console.WriteLine(base.Bookid);
            Console.WriteLine(base.BookName);
            Console.WriteLine(base.Author);
            Console.WriteLine(base.pages);
            Console.WriteLine(base.Price);
            //  throw new NotImplementedException();
            Console.WriteLine("Historical books display rich history.....");
        }

        public override void FindBooksDetailsByID(int id)
        {
            if (id<=0)
            {
                //throw new BookNotFoundException("Book  no must be greater than 0... this is a invalid book id");
                throw new BookNotFoundException();
            }
            else
            {
                Console.WriteLine("Trying to find... Pls wait...");
            }


        }
    }

    public class Comics : Books
    {
        public override void BookDescription()
        {
            //throw new NotImplementedException();
            Console.WriteLine(base.Bookid);
            Console.WriteLine(base.BookName);
            Console.WriteLine(base.Author);
            Console.WriteLine(base.pages);
            Console.WriteLine(base.Price);
            Console.WriteLine("Read this, when u r bored.....");
        }

        public override void FindBooksDetailsByID(int id)
        {
            if (id < 0)
            {
                throw new BookNotFoundException("Book  no must be greater than 0... this is a invalid book id");
            }
            else
            {
                Console.WriteLine("Trying to find... Pls wait...");
            }
        }
    }



    [Serializable]
    public class BookNotFoundException : Exception
    {
        public BookNotFoundException() { }

        public BookNotFoundException(string message) : base(message) { }

        public BookNotFoundException(string message, Exception inner) : base(message, inner) { }

        protected BookNotFoundException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }

    }

}

﻿using System;
using System.IO;

namespace FileHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            //File.Create("demo.txt");

            //  File.WriteAllText("demo1.txt", "Thsis is  a  file ");
            //  string c= File.ReadAllText("demo1.txt");
            // Console.WriteLine(c);

            //File.WriteAllText(@"D:\Sulakshana\myfile.txt", "this is file created in the folder");

            //   File.Copy("demo1.txt", @"D:\Sulakshana\demo1.txt");
            //File.Move
            //File.Delete
            //File.AppendAllText
string[] dirs=Directory.GetDirectories(@"firstDir");

            foreach (var item in dirs)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("-------------");
         string[] files   =Directory.GetFiles(@"firstDir\Subdir");
            foreach (var item in files)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
            DriveInfo[] dinfo=DriveInfo.GetDrives();
            foreach (var item in dinfo)
            {
                Console.WriteLine(item.Name);
                Console.WriteLine(item.IsReady);
                Console.WriteLine(item.TotalSize);
                Console.WriteLine(item.AvailableFreeSpace);
                Console.WriteLine(item.DriveFormat);
                Console.WriteLine(item.DriveType);
                Console.WriteLine(item.RootDirectory);
                Console.WriteLine(item.VolumeLabel);
                Console.WriteLine("-------");
            }
            
            //Directory.CreateDirectory("firstDir/SubDir");

            //Console.WriteLine("done");
            Console.Read();
        }
    }
}

﻿using System;


namespace ArraysDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            arr[0] = 1110;
            arr[1] = 210;
            arr[2] = 30;
            arr[3] = 4;
            arr[4] = 51;

            int[] arr1 = new int[4] { 1000, 2000, 3000, 4000 };
            int[] arr2 = new int[] { 1000, 2000, 3000, 4000 };

            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }


            int[] copiedArr = new int[arr.Length];
            Array.Copy(arr, copiedArr, 5);
            Console.WriteLine("After copying.....");
            foreach (var item in copiedArr)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("sorting");
            Array.Sort(arr);//ascending
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Descending/reverse");
            Array.Reverse(arr);
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Index of");
            int ElementIndex = Array.IndexOf(arr, 4);
            Console.WriteLine(ElementIndex);
            Console.WriteLine("-----Matrix----");
            int[,] matrix = new int[2, 4] {{ 1, 2, 3, 4 },{5,6,7,8 } };
            foreach (var item in matrix)
            {
                Console.Write(item +"\t");
                
            }
            Console.WriteLine();
            Console.WriteLine("-----Jagged Array-----");
            int[][] jagged = new int[4][];
            jagged[0] = new int[5] { 1, 2, 3, 4, 5 };
            jagged[1] = new int[6] { 10, 20, 30, 40, 50,60 };
            jagged[2] = new int[4] { 100, 200, 300, 400};
            jagged[3] = new int[2] { 1000, 2000 };

            foreach (var item in jagged)
            {
                foreach (var innerElement in item)
                {
                    Console.Write(innerElement + "\t");
                }
                Console.WriteLine();
            }





















            Console.Read();
        }
    }
}

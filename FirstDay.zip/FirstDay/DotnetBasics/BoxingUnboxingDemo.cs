﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotnetBasics
{
    class BoxingUnboxingDemo
    {
        static int Main()
        {

            //Boxing----Only value types can be boxed
            
            short p;//int 16
            int t1;//int 32
            long l1;//int 64
            t1 = 100;
            
            //to achieve Unboxing we use casting

            int j1 = 100;
            object o1 = j1;//Boxing
            int j2 = (int)o1;//Unboxing

            string g = "Welcome";
            object o2 = g;
            //string y1 =(string) o2;
            string y1 = o2.ToString();

            object pk1;//ToString(),GetType(),GetHashCode(),Equals()
            int pk2;
            pk1 = 123;
            pk2 = 123;
            Console.WriteLine("comparing object with int with same value");
           bool areEqual= pk1.Equals(pk2);
            Console.WriteLine(areEqual);
            Console.WriteLine("--------Comparing string with object same value -----");
            pk1 = 12356677777.555555555;
            string value = "123";
            areEqual = pk1.Equals(value);
            Console.WriteLine(areEqual);
            Console.WriteLine("type of pk1 =" + pk1.GetType());
            Console.WriteLine("type of value =" + value.GetType());
            Console.WriteLine("------------------------");
            string d = "Hello";
            char[] d1 =new char[5] { 'H','e','l','l','o' };
            string d2 = "Hello";
            Console.WriteLine( "are d and d1 equal = " + d.Equals(d1));

            Console.WriteLine("are d and d2 equal = " + d.Equals(d2));

            Console.WriteLine();
            Console.WriteLine("get hash code of d= " + d.GetHashCode());
            Console.WriteLine("get hash code of d1= " + d1.GetHashCode());





            Console.ReadKey(); 
















           
                    


            return 0;
        }
    }
}

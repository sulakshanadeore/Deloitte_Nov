﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotnetBasics
{
    class SecondClass
    {
        

        static void Main(string[] args)
        {
            Console.WriteLine("Enter your name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter password");
            string pwd = Console.ReadLine();
            //ValidateUser(name, pwd);

            bool ans=CheckUserIDandPassword(name, pwd);
            if (!ans)
            {
                Console.WriteLine("Incorrect password");
                
            }
            else
            {
                WelcomeUser(name);
            }



            Console.Read();
        }

        static bool CheckUserIDandPassword(string username, string password)
        {
            bool status = false;
            if (username!=null && password=="abc@123")
            {
                status = true;
            }
            return status;
        
        }

        static void ValidateUser(string username, string password)
        {
            if (username != null && password == "abc@123")
            {
                WelcomeUser(username);
            }
            else
            {
                Console.WriteLine("Incorrect Password");
            }
        
        }

        static void WelcomeUser(string username)
        {
            Console.WriteLine("Welcome  " + username);
        }
    }
}

﻿using System;


namespace DotnetBasics
{
    class Program
    {
        static void Main(string[] args)
        {

            
            ConsoleColor c1 = ConsoleColor.Red;
            Console.BackgroundColor = c1;

            ConsoleColor c2 = ConsoleColor.Green;
            Console.ForegroundColor = c2;


            //int j = null;--error
            Nullable<int> j = null;
            string s1 = null;


            Console.Write("Hello World");
            Console.WriteLine("Welcome");
            int i = 100;
            Console.WriteLine(i);
            string s = "Gauri";
            Console.WriteLine(s);
            float pi = 3.14f;
            Console.WriteLine(pi);
            DateTime dt = new DateTime(2022, 11, 15);
            Console.WriteLine(dt);
            char c = 'A';
            Console.WriteLine(c);
            Console.WriteLine();
            //convert string TO A INT

            Method1();//calling a method
            string s2=Greet();
            Console.WriteLine(s2);
                     
            Console.WriteLine("enter first number to add");
            int fno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter second number to add");
            int sno = Convert.ToInt32(Console.ReadLine());
            int addans=add(fno, sno);
            Console.WriteLine(addans);
                
            Console.ReadLine();
        }
        private static int add(int i, int j)
        {
            int k=i + j;
            return k;
        }


        private static string Greet()
        {

            string s = "Hello All";
            return s;
        }
        private static void Method1()
        {
            Console.WriteLine("enter a number");
            int no1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter another number");
            int no2 = Convert.ToInt32(Console.ReadLine());
            double ans = Math.Pow(no1, no2);
            Console.WriteLine(ans);
        }
    }
}

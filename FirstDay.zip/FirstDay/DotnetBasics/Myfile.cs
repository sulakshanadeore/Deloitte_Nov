﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotnetBasics
{
    class Demo
    {

        internal static bool CheckUserIDandPassword(string username, string password)
        {
            bool status = false;
            if (username != null && password == "abc@123")
            {
                status = true;
            }
            return status;

        }

        internal static void ValidateUser(string username, string password)
        {
            if (username != null && password == "abc@123")
            {
                WelcomeUser(username);
            }
            else
            {
                Console.WriteLine("Incorrect Password");
            }

        }

      internal  static void WelcomeUser(string username)
        {
            Console.WriteLine("Welcome  " + username);
        }

    }

    class ThirdClass
    {
        static void Main(string[] args)
        {
            Demo.ValidateUser("ashwini", "abc@1234");
            Console.Read();
        }

    }
}

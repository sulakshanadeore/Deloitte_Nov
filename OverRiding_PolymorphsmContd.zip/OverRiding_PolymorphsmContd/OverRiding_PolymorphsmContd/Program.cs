﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpLibrary;
namespace OverRiding_PolymorphsmContd
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.BasicSal = 10000;
            Console.WriteLine("BAsic Salary= " + emp.BasicSal);
            double sal=emp.CalculateSalary();
            Console.WriteLine("From Emp class=" + sal);
            Console.WriteLine("-----------------------");

            Manager mgr = new Manager();
            mgr.BasicSal = 10000;
            Console.WriteLine("BAsic Salary= " + mgr.BasicSal);
            sal =mgr.CalculateSalary();
            Console.WriteLine("from mgr class=" + sal);
            Console.WriteLine("--------------------");
            
            SeniorManager senmgr = new SeniorManager();
            senmgr.BasicSal = 10000;
            Console.WriteLine("BAsic Salary= " + senmgr.BasicSal);
            sal =senmgr.CalculateSalary();

            Console.WriteLine("from senior manager" +sal);
            Console.WriteLine("---------------------");
            Console.Read();

            


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class RegisteredCustomer
    {
      public int[] bookIndex = new int[3];
       public DateTime CalculateReturnDate()
        {
            Console.WriteLine("The borrowed date= " + DateTime.Now.ToShortDateString());
            DateTime dt= DateTime.Now.AddDays(7);
            return dt;
       }

    }

    class PaidCustomer:RegisteredCustomer
    {
    }

    class Books
    {
        public Books()
        {
            Console.WriteLine("1. ABC");
            Console.WriteLine("2. PQR");
            Console.WriteLine("3. XYZ");
            Console.WriteLine("4. yyy");
            Console.WriteLine("5. zzz");

        }
    }

    class Library
    {
        static void Main(string[] args)
        {
            Console.WriteLine("R u paid customer -nter 1 , R u Registered Customer ---neter 2 ");
            int c = Convert.ToInt32(Console.ReadLine());
            int j;
            switch (c)
            {
                case 1:
                    PaidCustomer paid = new PaidCustomer();
                    Books booksAvailable = new Books();
                    for (int i = 0; i < 3; i++)
                    {
                        Console.WriteLine("Enter bookno");
                        j = Convert.ToInt32(Console.ReadLine());
                        paid.bookIndex[i] = j;

                    }

                    Console.WriteLine("You have selected teh following books");
                    foreach (var item in paid.bookIndex)
                    {
                        Console.WriteLine(item);
                    }
                    
                    Console.WriteLine("your return date= " +  paid.CalculateReturnDate());
                    
                    break;
                case 2:
                    RegisteredCustomer registered = new RegisteredCustomer();
                    Books booksAvailableNow = new Books();

                    break;
                default:
                    break;
            }

            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{

    enum CustomerTypes
    {
        Registered=1,
        Paid=2
    }

    class Librarycustomer
    {
        public void Select()
        {
            Console.WriteLine("1.Registered \n 2.Paid");
            CustomerTypes ch = (CustomerTypes)Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(ch);

                }
    }

    class SecondLibrary
    {
        static void Main(string[] args)
        {
            Librarycustomer c = new Librarycustomer();
            c.Select();
            Console.Read();
        }
    }
}

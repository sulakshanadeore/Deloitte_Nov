﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Plans p = new Plans();
            //p.Plan299(1000, true, false, 28.4f);
            p.Plan299(true, 2000, true);

            Console.Read();
        }
    }
}

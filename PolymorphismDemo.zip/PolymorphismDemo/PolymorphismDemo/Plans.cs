﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class Plans
    {
        public void Plan299(int callingMinutes,bool local,bool intl,float Validity)
        {
            Console.WriteLine("Calling minutes=" + callingMinutes);
            Console.WriteLine("Local=" + local);
            Console.WriteLine("International=" + intl);
            Console.WriteLine("Plan validity=" + Validity);
       }

        public void Plan299(bool local, int callingMinutes,  bool intl)
        {
            Console.WriteLine("Calling minutes=" + callingMinutes);
            Console.WriteLine("Local=" + local);
            Console.WriteLine("International=" + intl);
        }
        public int Plan299(bool local, int callingMinutes, bool intl,int dataplan)
        {
            Console.WriteLine("Calling minutes=" + callingMinutes);
            Console.WriteLine("Local=" + local);
            Console.WriteLine("International=" + intl);
            Console.WriteLine("Data plan= " + dataplan);
            return 0;
        }

        public float Plan299(bool local, int callingMinutes, bool intl, int dataplan, bool trueUnlimited)
        {
            Console.WriteLine("Calling minutes=" + callingMinutes);
            Console.WriteLine("Local=" + local);
            Console.WriteLine("International=" + intl);
            Console.WriteLine("Data plan= " + dataplan);
            Console.WriteLine("Truly unlimited =  " + trueUnlimited);


            return 0;
        }







    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectOrientedProgrammingDemo
{
    class Manager:Employee
    {
        public string Mgrname
        {
            set;
            get;
        }

        public string ShowEmployeeName 
        {
            get 
            { 
                return base.EmployeeName; 
            }
            set 
            {
                base.EmployeeName = value; 
            }
        }
        public string Hierarchy()
        {

            return ShowEmployeeName + "reports to " + 
                Mgrname;
        
        }
    }
}

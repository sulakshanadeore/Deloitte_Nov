﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectOrientedProgrammingDemo
{
    class Employee
    {
        private int _empid;

        public int EmployeeID
        {
            get { return _empid; }
            set { _empid = value; }
        }

        private string _ename;

        public string EmployeeName
        {
            get { return _ename; }
            set { _ename = value; }
        }

        private int _deptno;

        public int Deptno
        {
            get { return _deptno; }
            set { _deptno = value; }
        }

        private DateTime _Joiningdate;

        public DateTime DateofJoining
        {
            get { return _Joiningdate; }
            set { _Joiningdate = value; }
        }

        private string _panno;

        public string PanCardNo
        {
            get 
            {
                return _panno;
            }
            set
            {
                if (string.IsNullOrEmpty(value) && value.Length>10)
                {
                    Console.WriteLine("its not valid value");
                }
                else
                {
                    _panno = value;
                }
                
            
            }
        }
        
        
        //AIP-Auto implemented property
        public int Basic { get; set; }


        //Only get-----Read only property
        public double NetSalary
        { 
            get 
            {
                double hra = Basic * .10;
                double da = Basic * .20;
                double ta = Basic * .10;
                return Basic + hra + ta + da;
            }
        
        }

        //Write only property
        private string _pwd;
        public string Password
        {
            set { _pwd = value; }
        }

        bool userchoice = false;
        public bool ForgotPassword
        {
            set {
                userchoice = value;
                if (userchoice==true)
                {
                    Console.WriteLine(ResetPassword);
                }
            }
        }

        private string ResetPassword
        {
            get {
                _pwd= string.Concat(EmployeeName, DateofJoining.Date.ToLongDateString());
                return _pwd; 
            }
               
        }





    }
}

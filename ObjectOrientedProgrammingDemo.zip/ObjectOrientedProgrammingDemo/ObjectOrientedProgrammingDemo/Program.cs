﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectOrientedProgrammingDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            // Products p = new Products();
            // Console.WriteLine("Enter ProductID ");
            // p.ProductID=Convert.ToInt32(Console.ReadLine());



            // Console.WriteLine("enter Product Name");
            // p.ProductName = Console.ReadLine().Trim();


            // Console.WriteLine("Enter brand");
            // p.Brand = Console.ReadLine().Trim();

            // Console.WriteLine("Enter Price");
            // p.Price = Convert.ToDouble(Console.ReadLine());
            // Console.WriteLine("you have ordered the following ");
            // Console.WriteLine("productid " + p.ProductID);
            // Console.WriteLine("product name " + p.ProductName);
            // Console.WriteLine("product Price (Rs) " + p.Price); 
            // Console.WriteLine("product brand " + p.Brand);

            //// Console.WriteLine(p.SellingPrice);



            // EndSupplier c = new EndSupplier();
            // Console.WriteLine(c.ProductID);
            // Console.WriteLine(c.ProductName);
            // Console.WriteLine(c.Brand);
            // Console.WriteLine(c.ShowSellingPrice);


            Employee emp = new Employee();
            Console.WriteLine("enter employee id");
            emp.EmployeeID = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter employee name");
            emp.EmployeeName = Console.ReadLine();

            //Console.WriteLine("enter employee deptno");
            //emp.Deptno = Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine("enter employee  joining date");
            //emp.DateofJoining = Convert.ToDateTime(Console.ReadLine());

            //Console.WriteLine("Enter your pancard no");
            //emp.PanCardNo = Console.ReadLine();


            //Console.WriteLine("Enter basic sal");
            //emp.Basic = Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine("Enter net salary");
            //emp.NetSalary = Convert.ToDouble(Console.ReadLine());


            //Console.WriteLine("Enter your password");
            //emp.Password = Console.ReadLine();

            //Console.WriteLine("Did you forget your password, u can get it back");
            //emp.ForgotPassword = Convert.ToBoolean(Console.ReadLine());

            Console.WriteLine("enter mgr employeeid");
            Manager m = new Manager();
            m.EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter manager's name");
            m.ShowEmployeeName = emp.EmployeeName;
            m.Mgrname = Console.ReadLine();

            string s=m.Hierarchy();
            Console.WriteLine(s);

            Console.WriteLine("Display details");
            Console.WriteLine(emp.EmployeeID);
            Console.WriteLine(emp.EmployeeName);
            Console.WriteLine(emp.Deptno);
            Console.WriteLine(emp.DateofJoining);
            Console.WriteLine(emp.PanCardNo);
            Console.WriteLine(emp.Basic);
            Console.WriteLine(emp.NetSalary);
            





            Console.Read();


        }
    }
}

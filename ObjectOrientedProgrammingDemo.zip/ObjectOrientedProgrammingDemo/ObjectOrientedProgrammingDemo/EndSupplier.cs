﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectOrientedProgrammingDemo
{

    

    //Child Class--- get everything from the parent----except private
    class EndSupplier:Products
    {
        public int ShowProductID
        {
            set { base.ProductID = value;
    
            }
            get { return base.ProductID; }
        
        }
        //protected accessible to inherited class i.e. child class(EndSupplier) & inside the class where it is declared

        public double ShowSellingPrice
        {
            get { return base.SellingPrice; }
           
          }



       
        //base keyword can be only used here by the members of the class
        


    }
}

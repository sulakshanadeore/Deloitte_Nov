﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectOrientedProgrammingDemo
{
    class Demo1
    {
        static void Main(string[] args)
        {

            //string str = "ABCDE";
            //char data;
            //for (int i = 0; i < str.Length; i++)
            //{
            //     data=char.IsLetterOrDigit(str[i]);
            //}
            
            //char c1 = 'Z';
            //int asciiValue = (int)c1;
            //Console.WriteLine(asciiValue);
            //Console.ReadLine();
        }
    }
}

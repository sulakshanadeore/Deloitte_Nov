﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectOrientedProgrammingDemo
{
    //Base/Parent Class
    class Products
    {

        private int _productid;
        private string _prodname;
        private string _brand;
        private double _price;
        private double _sp;

        public int ProductID
        {
            set//Accept the data from the user
            {
                _productid = value;
            }
            get //Display the data to the user
            {
                return _productid;
            }

        }

        public string ProductName
        {
            set
            {
                _prodname = value;
            }

            get {
                return _prodname;
            }
        }

        public string Brand
        {
            set
            {
                _brand = value;
            }
            get 
            {
                return _brand;
            }
        }

        public double Price
        {
            set 
            { 
                _price = value; 
            }

            get 
            {

                //_sp = _price + (_price * .05);
                
                return _price;
            }
        
        }
        private  string _perishable;
         internal  string IsPerishable 
        {
            get { return _perishable; }
            set { _perishable = value; }
        }


        protected  double SellingPrice
        {
            get {
                
                _sp = _price + (_price * .05);


                return _sp; }
        }



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLibrary
{
   public class Manager : Employee
    {
        //public new void CalculateSalary()
        //{
        //    Console.WriteLine("Enter basic sal");
        //    int basic = Convert.ToInt32(Console.ReadLine());//20000
        //    Console.WriteLine("Enter da in % ");
        //    int da = Convert.ToInt32(Console.ReadLine());
        //    Console.WriteLine("Enter ta in % ");
        //    int ta = Convert.ToInt32(Console.ReadLine());
        //    Console.WriteLine("Enter hra in % ");
        //    int hra = Convert.ToInt32(Console.ReadLine());

        //    double grossSal = basic + (basic * (da + ta + hra)) / 100;
        //    Console.WriteLine(grossSal);

        //}

        public override double CalculateSalary()
        {

            double grossSal = base.CalculateSalary() + 20000;
            return grossSal;


        }

    }

    public class SeniorManager : Manager
    {
        public override sealed double CalculateSalary()
        {
            double grossSal = base.CalculateSalary() + 20000;
            return grossSal;


        }
    }

   public class Director : SeniorManager
    {

        public new double CalculateSalary()
        {
            double grossSal = base.CalculateSalary() + 20000;
            return grossSal;


        }

    }
}

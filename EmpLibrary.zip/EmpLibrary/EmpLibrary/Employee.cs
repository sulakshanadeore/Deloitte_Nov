﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLibrary
{
   public class Employee
    {
        public int Empid { get; set; }
        public double BasicSal { get; set; }
        public int TA { get; set; }
        public int HRA { get; set; }
        public int DA { get; set; }
        public double GrossSal { get; set; }
        public virtual double CalculateSalary()
        {

            Console.WriteLine("Enter TA");
            this.TA = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter HRA");
            this.HRA = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter DA");
            this.DA = Convert.ToInt32(Console.ReadLine());
            this.GrossSal = this.TA + this.DA + this.HRA + this.BasicSal;
            Console.WriteLine(this.GrossSal);
            return this.GrossSal;
        }


    }
}
